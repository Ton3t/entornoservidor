var productos = [];

function recibeProductos() {

    //peticion ajax q recibe los productos y los pinta en el select //
    var ajax1 = new XMLHttpRequest();
    ajax1.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            productos = JSON.parse(this.responseText);
            let select = document.getElementById("idarticulo");
            for (let i = 0; i < productos.length; i++) {
                if(productos[i] == null) {
                    i++;
                }
                else {
                    let option = document.createElement("option");
                    option.text = productos[i].descripcion;
                    option.value = productos[i].descripcion;
                    select.appendChild(option);
                }
            }
        } else {
            console.log(`Ha ocurrido un error: ${ajax1.status}`);
        }
    };
    ajax1.open("GET", "./json/productos.json", true);
    ajax1.send();
}

var usuarios = [];

function recibeClientes() {

    // peticion ajax que recibe los datos parseados y los inserta en un array al cargar la pagina //
    var ajax3 = new XMLHttpRequest();
    ajax3.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            usuarios = JSON.parse(this.responseText);
            let select = document.getElementById("idclientes");
            for (let i = 0; i < usuarios.length; i++) {
                let option = document.createElement("option");
                option.text = usuarios[i].nombre + " " + usuarios[i].apellidos;
                option.value = usuarios[i].nombre + " " + usuarios[i].apellidos;
                select.appendChild(option);
            }
        } else {
            console.log(`Ha ocurrido un error: ${ajax3.status}`);
        }
    };
    ajax3.open("GET", "./json/clientes.json", true);
    ajax3.send();
}

var ventas = [];
var arrayVentas = [];

function recibeVentas() {

    //peticion ajax q recibe las ventas o facturas genedas //
    var vajax1 = new XMLHttpRequest();
    vajax1.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            ventas = JSON.parse(this.responseText);
            for(let i = 0; i < ventas.length; i++) {
                if(ventas[i] != null) {
                    arrayVentas.push(ventas[i]);
                }
            }
            console.log(arrayVentas);
        } else {
            console.log(`Ha ocurrido un error: ${vajax1.status}`);
        }
    };
    vajax1.open("GET", "./json/ventas.json", true);
    vajax1.send();
}

var facturas = [];

function carrito() {
    // funcion que agrega los datos de los inputs al carrito //
    // datos //
    let cliente = document.getElementById("idclientes").value;
    let articulo = document.getElementById("idarticulo").value;
    let cantidad = document.getElementById("idcantidad").value;
    let precio = 0;
    let id = 0;
    console.log(getCookie("sesion"));
    for (let i = 0; i < productos.length; i++) {
        if (articulo == productos[i].descripcion) {
            precio = productos[i].precio;
        }
    }

    // zonas //
    let zcliente = document.getElementById("idclientes");
    let zarticulo = document.getElementById("idarticulo");
    let zcantidad = document.getElementById("idcantidad");
    let total = precio * cantidad;
    // 
    if (cliente != "" && articulo != "" && cantidad != 0) {
        if (ventas == null || ventas == "") {

            let factura = {
                "id": id,
                "nombre": cliente,
                "articulo": articulo,
                "cantidad": cantidad,
                "precio": precio,
                "total": total
            };
            totales += total;

            facturas.push(factura);
            crearTabla(id, cliente, articulo, cantidad, precio, total);

            //regFactura(facturas);
            document.getElementById("idarticulo").value = "";
            document.getElementById("idcantidad").value = "";
            precio = "";
            zcliente.style.borderColor = "black";
            zarticulo.style.borderColor = "black";
            zcantidad.style.borderColor = "black";
            inputComprar();
        } else {
            /*
            for (let i = 0; i < ventas.length; i++) {
                for (let j = 0; j < ventas[i].length; j++) {
                    id = ventas[i][j].id;
                }
            }
            */
            id = ventas.length;
            console.log(id);
            
            let factura = {
                "id": id,
                "nombre": cliente,
                "articulo": articulo,
                "cantidad": cantidad,
                "precio": precio,
                "total": total
            };
            totales += total;


            facturas.push(factura);
            crearTabla(id, cliente, articulo, cantidad, precio, total);

            //regFactura(facturas);
            document.getElementById("idarticulo").value = "";
            document.getElementById("idcantidad").value = "";
            precio = "";
            zcliente.style.borderColor = "black";
            zarticulo.style.borderColor = "black";
            zcantidad.style.borderColor = "black";
            inputComprar();
        }
    } else {

        // en caso de haber algun input incorrecto //

        alert("Porfavor rellene los campos en rojo");
        if (cliente == "") {
            zcliente.style.borderColor = "red";
        }
        if (articulo == "") {
            zarticulo.style.borderColor = "red";
        }
        if (cantidad == "") {
            zcantidad.style.borderColor = "red";
        }
    }
}

function regFactura(variable) {
    // peticion ajax q envia los datos a clientes.php //
    console.log(variable);
    var subir = new XMLHttpRequest();
    var datosUser = new FormData();
    datosUser.append("datos", JSON.stringify(variable));
    subir.open("POST", "./control/ventas.php", true);
    subir.send(datosUser);
}

function crearTabla(var1, var2, var3, var4, var5, var6) {

    // recogemos el id de la tabla y vamos pintando los datos que se van agregando al carrito 

    let tabla = document.getElementById("tabla");
    let tr = document.createElement("tr");
    let id = document.createElement("td");
    let nombre = document.createElement("td");
    let articulo = document.createElement("td");
    let cantidad = document.createElement("td");
    let total = document.createElement("td");
    let precio = document.createElement("td");

    id.innerHTML = var1;
    tr.appendChild(id);
    nombre.innerHTML = var2;
    tr.appendChild(nombre);
    articulo.innerHTML = var3;
    tr.appendChild(articulo);
    precio.innerHTML = var5;
    tr.appendChild(precio);
    cantidad.innerHTML = var4;
    tr.appendChild(cantidad);
    total.innerHTML = var6;
    tr.appendChild(total);
    tabla.appendChild(tr);
    facturaTotal();
}

var totales = 0;

function facturaTotal() {
    // recogemos el id de la tabla y vamos sumando los totales de la factura
    let td2 = document.getElementById("idtuto");
    td2.innerHTML = totales;
}

function inputComprar() {

    // funcion que nos crea un input para poder comprar el carrito
    // nos añade un evenlistener con la funcion comprarCarrito
    let div = document.getElementById("idcomprar");
    let input = document.createElement("button");
    let td = document.createElement("td");
    if (div.hasChildNodes()) {
        div.removeChild(div.childNodes[0]);
    }
    input.innerHTML = "COMPRAR";
    td.appendChild(input);
    div.appendChild(td);
    input.addEventListener("click", comprarCarrito);
    let disabled = document.getElementById("idclientes");
    disabled.disabled = true;
}

function comprarCarrito() {
    // funcion que compra el carrito si la cookie generada al entrar está todavía vigente 
    // en caso contrario entra en el else y nos recarga la página 
    if(getCookie("sesion") == "activa") {
        ventas.push(facturas);
        regFactura(ventas);
        alert("Venta realizada con exito");
        location.reload();
    } 
    else {
        alert("La sesión ha expirado, porfavor reinicie la página.");
        location.reload();
    }
}

function listener() {
    // funcion para añadir evenlistener
    document.getElementById("idcarro").addEventListener("click", carrito);
}

function setCookie(cname, cvalue, exdays) {
    // funcion para generar la cookie
    var d = new Date();
    d.setTime(d.getTime() + 1 + (exdays * 60 * 1000));
    var expires = "expires=" + d.toString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    //funcion para recoger la cookie
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

window.onload = function () {
    // funciones que cargamos al iniciar la página -- 
    // creamos una cookie que dura 30 minutos para verificar la sesion
    // si está activa podrá comprar - si ha caducado no le nos dejará realizar la compra
    setTimeout(() => {
        alert("Faltan 5 minutos para que expire la sesion.");
    }, (25 * 60 * 1000));
    setTimeout(()=> {
        alert("La sesión ha expirado.");
        setCookie("sesion", "inactiva", 100000000);
    }, (30 * 60 * 1000));
    this.recibeClientes();
    this.recibeProductos();
    this.recibeVentas();
    this.listener();
    this.setCookie("sesion", "activa", 30);
}