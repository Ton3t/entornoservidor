var productos = [];
var arrayProductos = [];

function recibeProductos() {

    // funcion para recibir datos de productos y pintarlos en el select //

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            productos = JSON.parse(this.responseText);
            for(let i = 0; i < productos.length; i++) {
                if(productos[i] == null) {

                }
                else {
                    arrayProductos.push(productos[i]);
                }
            }
            console.log(productos);
            let select = document.getElementById("idarti");
            for (let i = 0; i < productos.length; i++) {
                if (productos[i] == null) {
                    
                } else {
                    let option = document.createElement("option");
                    option.text = productos[i].descripcion;
                    option.value = productos[i].descripcion;
                    select.appendChild(option);
                    
                }
            }
        }
    };
    xmlhttp.open("GET", "./json/productos.json", true);
    xmlhttp.send();
}

function regProductos(variable) {
    // peticion ajax q envia los datos a articulos.php //
    console.log(variable);
    var subir = new XMLHttpRequest();
    var datosUser = new FormData();
    datosUser.append("datos", JSON.stringify(variable));
    subir.open("POST", "./control/articulos.php", true);
    subir.send(datosUser);
}

function enviarDatos() {

    // enviar datos con los valores de los inputs //

    // datos //
    let ref = document.getElementById("idref").value;
    let desc = document.getElementById("iddescripcion").value;
    let familia = document.getElementById("idfamilia").value;
    let precio = document.getElementById("idprecio").value;

    // zonas //
    let zref = document.getElementById("idref");

    let zdesc = document.getElementById("iddescripcion");
    let zfamilia = document.getElementById("idfamilia");
    let zprecio = document.getElementById("idprecio");

    if (ref != "" && desc != "" && familia != "" && precio != "") {
        if(arrayProductos == null) {
            let producto = {
                "ref": ref,
                "descripcion": desc,
                "familia": familia,
                "precio": precio
            };
            arrayProductos.push(producto);
            regProductos(arrayProductos);
            location.reload();
        }
        else {
            let producto = {
                "ref": ref,
                "descripcion": desc,
                "familia": familia,
                "precio": precio
            };
            arrayProductos.push(producto);
            regProductos(arrayProductos);
            location.reload();
        }
        

    } else {

        // funcion que pinta un campo si está mal //

        alert("Revisa los campos");
        if (ref == "") {
            zref.style.borderColor = "red";
        }
        if (desc == "") {
            zdesc.style.borderColor = "Red";
        }
        if (familia == "") {
            zfamilia.style.borderColor = "red";
        }
        if (precio == "") {
            zprecio.style.borderColor = "red";
        }
    }
}

var contaID = 0;

function muestraArticulos() {

    // funcion para mostrar los datos en los inputs //

    inputModificar();
    contaID = 0;
    let valor = document.getElementById("idarti").value;
    console.log(valor);
    for (let i = 0; i < arrayProductos.length; i++) {
        if (valor == arrayProductos[i].descripcion) {
            pintarDatos(arrayProductos[i].ref, arrayProductos[i].descripcion, arrayProductos[i].familia, arrayProductos[i].precio);
            contaID = i;
        }
    }
}

function inputModificar() {

    // funcion que borra y vuelve a pintar los botones borrar y modificar //

    let zona = document.getElementById("btnMod");
    let input = document.createElement("button");
    input.setAttribute("class", "tr");
    while (zona.childElementCount > 0) {
        zona.removeChild(zona.childNodes[0]);
    }
    input.innerHTML = "Modificar";
    input.addEventListener("click", modArt);
    zona.appendChild(input);
    let zona1 = document.getElementById("btnEliminar");
    let input1 = document.createElement("button");
    input1.setAttribute("class", "tr");
    while (zona1.childElementCount > 0) {
        zona1.removeChild(zona1.childNodes[0]);
    }
    input1.innerHTML = "Borrar";
    input1.addEventListener("click", delArt);
    zona1.appendChild(input1);
}

function modArt() {
    let ref = document.getElementById("idref").value;
    let desc = document.getElementById("iddescripcion").value;
    let familia = document.getElementById("idfamilia").value;
    let precio = document.getElementById("idprecio").value;
    // funcion que modifica productos según los valores de los inputs //
    if (ref != "" && desc != "" && familia != "" && precio != "") {
        productos[contaID] = arrayProductos[contaID];
        enviarDatos();
    }
    else {
        let zref = document.getElementById("idref");

    let zdesc = document.getElementById("iddescripcion");
    let zfamilia = document.getElementById("idfamilia");
    let zprecio = document.getElementById("idprecio");
    alert("Revisa los campos");
    if (ref == "") {
        zref.style.borderColor = "red";
    }
    if (desc == "") {
        zdesc.style.borderColor = "Red";
    }
    if (familia == "") {
        zfamilia.style.borderColor = "red";
    }
    if (precio == "") {
        zprecio.style.borderColor = "red";
    }

    }

    
}

function delArt() {

    // funcion que borrar directamente un articulo según su id//
    arrayProductos.splice(contaID, 1);
    regProductos(arrayProductos);
    location.reload();
}

function pintarDatos(v1, v2, v3, v4) {

    // funcion que pinta los datos en los inputs según sus parámetros //

    document.getElementById("idref").value = v1;
    document.getElementById("iddescripcion").value = v2;
    document.getElementById("idfamilia").value = v3;
    document.getElementById("idprecio").value = v4;
}


function listener() {
    // agregamos eventlistener a un par de funciones //
    document.getElementById("idregistrar").addEventListener("click", enviarDatos);
    document.getElementById("idarti").addEventListener("change", muestraArticulos);

}

window.onload = function () {
    // funciones que se cargan al entrar en la pagina //
    this.listener();
    this.recibeProductos();
}