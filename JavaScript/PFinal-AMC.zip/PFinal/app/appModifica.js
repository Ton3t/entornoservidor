var ventas = [];
var totales = 0;
function recibeVentas() {

    //peticion ajax q recibe las ventas o facturas genedas y pinta los datos en el select //
    var vajax1 = new XMLHttpRequest();
    vajax1.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            ventas = JSON.parse(this.responseText);
            console.log(ventas);
            let select = document.getElementById("idnventa");
            for (let i = 0; i < ventas.length; i++) {
                let option = document.createElement("option");
                option.innerHTML = i;
                option.value = i;
                select.appendChild(option);
            }
        } else {
            console.log(`Ha ocurrido un error: ${vajax1.status}`);
        }
    };
    vajax1.open("GET", "./json/ventas.json", true);
    vajax1.send();
}


var dateFinale = 0;
var idventa = 0;
document.getElementById("idnventa").addEventListener("change", muestraFac);

function muestraFac() {

    // funcion para mostrar los datos en una tabla //
    cont = 0;
    dateFinale = 0;
    borrarTabla();
    let totales2 = 0;
    let recibe1 = document.getElementById("idnventa").value;
    let recibe = parseInt(recibe1);
    dateFinale = recibe;
    for (let i = 0; i < ventas.length; i++) {
        for (let j = 0; j < ventas[i].length; j++) {
            if (recibe == ventas[i][j].id) {
                crearTabla(ventas[i][j].id, ventas[i][j].nombre, ventas[i][j].articulo, ventas[i][j].cantidad, ventas[i][j].precio, ventas[i][j].total);
                totales2 += ventas[i][j].precio * ventas[i][j].cantidad;
                totales = totales2;
                idventa = ventas[i][j].id;
                facturaTotal();
            }
        }
    }
}

function crearTabla(var1, var2, var3, var4, var5, var6) {

    // funcion que crea y pinta la tabla //

    let tabla = document.getElementById("idtabla");
    let tr = document.createElement("tr");
    let id = document.createElement("td");
    let nombre = document.createElement("td");
    let articulo = document.createElement("td");
    let cantidad = document.createElement("td");
    let total = document.createElement("td");
    let precio = document.createElement("td");
    let input = inputBorrar();
    tr.className = "fila";
    console.log(tabla);
    id.innerHTML = var1;
    id.className = "tr";
    id.setAttribute("id", "id");
    tr.appendChild(id);
    nombre.innerHTML = var2;
    nombre.className = "tr";
    nombre.setAttribute("id", "nombre");
    tr.appendChild(nombre);
    articulo.innerHTML = var3;
    articulo.className = "tr";
    articulo.setAttribute("id", "articulo");
    tr.appendChild(articulo);
    precio.innerHTML = var5;
    precio.className = "tr";
    precio.setAttribute("id", "precio");
    tr.appendChild(precio);
    cantidad.innerHTML = var4;
    cantidad.className = "tr";
    cantidad.setAttribute("id", "cantidad");
    tr.appendChild(cantidad);
    total.innerHTML = var6;
    total.className = "tr";
    total.setAttribute("id", "total");
    tr.appendChild(total);
    tr.appendChild(input);
    tabla.appendChild(tr);


}

function facturaTotal() {

    // funcion para pintar el total de la factura //
    let td2 = document.getElementById("idtuto");
    td2.innerHTML = totales;
}

var cont = 0;
var comprobarFila = 0;

function inputBorrar() {
    // funcion para añadir un input al lado de la fila y podamos borrarla de la factura //
    var input = document.createElement("button");
    var td = document.createElement("td");
    input.innerHTML = "Borrar";
    input.setAttribute("class", "inborrar");
    input.setAttribute("id", cont);
    td.appendChild(input);
    input.addEventListener("click", borrarFila2);
    
    
    input.addEventListener("click" ,()=>{
        comprobarFila = input.id;
        console.log(comprobarFila);
    });
    
    console.log(comprobarFila);
    cont++;
    return td;
}


function borrarFila2(e) {
    ventas[idventa].splice(ventas[comprobarFila], 1);
    // funcion para borrar la fila que ejecuta dos funciones mas //
    e.target.parentNode.parentNode.remove();
    actualizaTotal();
    inputModificar();
}

function actualizaTotal() {

    // actualizamos total //
    let td2 = document.getElementById("idtuto");
    let contador = document.getElementsByClassName("fila").length;
    let tabla = document.getElementById("idtabla");
    let t = 0;
    for (let i = 0; i < contador; i++) {
        let datos = tabla.childNodes[i + 2].childNodes[5].textContent;
        let factura = parseInt(datos);
        t = t + factura;
    }
    totales = t;
    td2.innerHTML = t;
}

function borrarTabla() {

    //funcion que borra la tabla por si pinchamos en otra factura //
    let dataTabla = document.getElementById("idtabla");
    while (dataTabla.childElementCount > 1) {
        dataTabla.removeChild(dataTabla.childNodes[2]);
    }
}



function inputModificar() {
    
    // funcion que crea el boton modificar y le añade la funcion facturarVenta
    let zona = document.getElementById("modificaVenta");
    let input = document.createElement("button");
    while (zona.childElementCount > 1) {
        zona.removeChild(zona.childNodes[2]);
    }
    input.innerHTML = "Modificar";
    input.addEventListener("click", facturarVenta);
    zona.appendChild(input);
}


function facturarVenta() {

    // se espera un segundo y llama a regFactura para modificar la venta

    //setTimeout(() => {
    //for (let i = 0; i < ventas.length; i++) {
    //    if (i == dateFinale) {
            regFactura(ventas);
            location.reload();
    //    }
   // }
   // }, 1000);
    
}

function carrito() {

    // funcion que recoge los datos de los inputs y nos registra la factura //
    // datos //
    let id = document.getElementById("id").value;
    let nombre = document.getElementById("nombre").value;
    let articulo = document.getElementById("articulo").value;
    let precio = document.getElementById("precio").value;
    let cantidad = document.getElementById("cantidad").value;
    let total = document.getElementById("total").value;

    let factura = {
        "id": id,
        "nombre": nombre,
        "articulo": articulo,
        "cantidad": cantidad,
        "precio": precio,
        "total": total
    };

    ventas.push(factura);
    regFactura(ventas);
}

function regFactura(variable) {
    // peticion ajax q envia los datos a clientes.php //
    console.log(variable);
    var subir = new XMLHttpRequest();
    var datosUser = new FormData();
    datosUser.append("datos", JSON.stringify(variable));
    subir.open("POST", "./control/ventas.php", true);
    subir.send(datosUser);
}



window.onload = function () {

    //funciones que se cargan al cargar la página //
    this.recibeVentas();
}